# Term project report (LaTeX, IEEEtran conference)

- `main.tex`: the report, in the format of the previous course report (IEEE conference two-column, 10 pt; teal
  sections "1" and subsections "2.1", orange sub-subsections "1.01" / "3.91"; bordered tables; author-year citations
  with the `ACM-Reference-Format` BibTeX style). If Overleaf cannot find that style, use `IEEEtran` instead
  (numeric citations).
- `refs.bib`: references; every entry is marked `% TODO verify` until checked on Google Scholar.
- `tables/*.tex`: **generated** by `python scripts/make_report_tables.py` (one booktabs tabular each; captions stay in
  `main.tex`). Do not edit by hand.
- `figures/F*.pdf`: **generated** by `python scripts/make_figures.py --out report/figures --formats pdf`.
  `figures/f_workflow.tex` and `figures/f0_architecture.tex` (TikZ) are drawn by hand and hold no results;
  `figures/captions.md` lists each generated figure's source files.

Regenerate both after any new result (e.g. the EfficientNetV2-S ISIC 2020 run), from the project folder:
```
python scripts/make_report_tables.py
python scripts/make_figures.py --out report/figures --formats pdf
```

## Overleaf
1. Zip the contents of this `report/` folder (so `main.tex` is at the top level of the zip).
2. Overleaf: New Project → Upload Project → choose the zip.
3. Menu → Settings: Compiler `pdfLaTeX`, Main document `main.tex`, TeX Live version the latest.
4. Recompile. IEEEtran, booktabs, TikZ and the other packages are part of Overleaf's TeX Live.

After regenerating tables or figures locally, upload only the changed files (Overleaf: Upload → select files,
overwrite) or re-upload the whole zip as a new project.
