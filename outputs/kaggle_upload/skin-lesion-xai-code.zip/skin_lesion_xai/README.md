# skin_lesion_xai

An explainable hybrid CNN-Transformer (EfficientNetV2 + Swin Transformer + cross-attention fusion)
for skin lesion classification from dermoscopic images. CSE 6231 Deep Learning term project.

Status: **Milestone 2 (baselines)**. The data pipeline (Milestone 1) is done. Fusion and XAI come in Milestone 3.
No results have been produced yet. Every number in this project must come from a script's output.

## Setup (Windows, PyCharm)

1. Install Python 3.11 from python.org (tick "Add python.exe to PATH").
2. In PyCharm, open the `skin_lesion_xai/` folder. Under Settings → Python Interpreter, choose
   Add Interpreter → Virtualenv, set the location to `skin_lesion_xai/.venv` and the base interpreter to Python 3.11.
3. In the PyCharm terminal (venv active):
   ```
   pip install torch torchvision --index-url https://download.pytorch.org/whl/cu124
   pip install -r requirements.txt
   pip install -e .
   python -c "import torch; print(torch.__version__, torch.cuda.is_available())"
   ```
   The last line should print `True`. `pip install -e .` makes `skin_lesion_xai` importable from the scripts and tests.

## Data layout

Paths are set in `configs/data/*.yaml`. Raw data lives outside this folder, in `Deep_learning/`:

```
Deep_learning/
├── ISIC/diagnosis_confirm_type/        HAM10000 images, 10,015 JPGs, 600x450
├── datasets/
│   ├── ham10000_extra/
│   │   ├── HAM10000_metadata.csv       Harvard Dataverse (lesion_id, image_id, dx, ...)
│   │   └── masks/                      HAM10000_segmentations_lesion_tschandl, 10,015 PNGs
│   └── isic2020/
│       ├── images/                     Kaggle "ISIC 2020 JPG 256x256 RESIZED", 33,126 JPGs
│       └── train-metadata.csv          isic_id, patient_id, target
└── skin_lesion_xai/                    this project
```

`Deep_learning/HAM10000/` (224x224 copies) is not used: the masks are 600x450, and the
full-resolution images leave room for random-crop augmentation.

On Kaggle or Colab, change `data_root` and the relative paths in the data configs.

### Training ISIC 2020 on Kaggle
- Upload two private Kaggle datasets:
  - `skin-lesion-xai-code`: a zip of `src/`, `configs/`, `scripts/`, `kaggle/`, `pyproject.toml`,
    `requirements.txt`, `README.md` and `data/splits/isic2020*.csv`;
  - `isic2020-256-local`: an unchanged zip of `datasets/isic2020/` (`images/` + `train-metadata.csv`).
- Paste `kaggle/run_isic2020.py` into a Kaggle script with GPU and internet on, attach both datasets, set `MODEL`,
  and use "Save & Run All". It trains with `configs/data/isic2020_kaggle.yaml` and the `kaggle_16gb` profile and
  stops before the 12 h session limit. To continue, attach that version's output and run again (it resumes).
- Evaluate the downloaded run here with the local data paths:
  `python scripts/evaluate.py --run outputs/runs/isic2020_<model> --data configs/data/isic2020.yaml [--val-only]`
- Binary runs: fix the decision thresholds on val before the test run (the test evaluation stops without them):
  `python scripts/select_threshold.py --run outputs/runs/isic2020_<model> [--min-sensitivity 0.80]`
  It reads `eval_val/predictions_val.csv` only and writes `eval_val/threshold.json` (Youden's J and the highest
  cutoff with val sensitivity >= 0.80). It refuses to run once `eval/` (test) exists.
- Paired bootstrap of two evaluated binary runs on the same test images (B minus A: AUC, AP, sensitivity and
  specificity at argmax and at each model's fixed cutoffs), written to `outputs/comparisons/`:
  `python scripts/compare_paired.py --runs outputs/runs/isic2020_convnext_t outputs/runs/isic2020_hybrid`

## Milestone 1: data pipeline

Run from the `skin_lesion_xai/` folder:

```
python scripts/prepare_ham10000.py      # -> data/splits/ham10000.csv (+ _summary.csv)
python scripts/prepare_isic2020.py      # -> data/splits/isic2020.csv (+ _summary.csv)
python scripts/preprocess_hair.py --config configs/data/ham10000.yaml --limit 50   # quick visual check
python scripts/preprocess_hair.py --config configs/data/ham10000.yaml              # full cache
python scripts/preprocess_hair.py --config configs/data/isic2020.yaml
pytest
```

- **Splits:** 70/15/15, stratified by class. HAM10000 is grouped by `lesion_id` and ISIC 2020 by
  `patient_id`, so one lesion or patient never ends up in two splits. The split CSV is written once
  (fixed seed) and every later run reads it. `--force` rebuilds it.
- **Hair removal:** a simplified OpenCV DullRazor (black-hat morphology, threshold, Telea inpainting),
  cached to `data/processed/<dataset>_dullrazor/`. Check `_samples.png` in that folder before turning
  on `use_hair_removal: true`. The ISIC 2020 kernel size (9 px at 256 px) is a starting value that
  still needs checking on the sample grid.
- **Transforms:** the train-time geometric augmentations are applied to the image and its mask together.

## Milestone 2: baselines and single branches

```
# smoke test (1 epoch, small stratified subsets; numbers are meaningless, only checks the chain runs)
python scripts/train.py --data configs/data/ham10000.yaml --model configs/model/resnet50.yaml --epochs 1 --max-train 200 --max-val 100 --run-name smoke_resnet50
# full run (local 3050 profile is the default; use --profile configs/train/kaggle_16gb.yaml on Kaggle/Colab)
python scripts/train.py --data configs/data/ham10000.yaml --model configs/model/resnet50.yaml
# continue an interrupted run from its last.pt (same arguments + --resume; resumes at the last finished epoch)
python scripts/train.py --data configs/data/ham10000.yaml --model configs/model/resnet50.yaml --run-name <run-name> --resume
# test-set evaluation of a finished run (once per final model)
python scripts/evaluate.py --run outputs/runs/<run-name>
# val-only evaluation (per-class metrics on val; the test split is not loaded), writes eval_val/
python scripts/evaluate.py --run outputs/runs/<run-name> --val-only
# explanation maps (Grad-CAM + attention maps) for a split, then their localisation scores against the lesion masks
python scripts/explain.py --run outputs/runs/<run-name> --split val
python scripts/eval_xai.py --run outputs/runs/<run-name> --split val
# sanity check: the same architecture with random weights (writes xai_val_random/)
python scripts/explain.py --run outputs/runs/<run-name> --split val --random-weights
python scripts/eval_xai.py --run outputs/runs/<run-name> --split val --random-weights
# explanation trust (Milestone 4): faithfulness, stability, parameter randomisation; needs xai_<split>/ for the
# paired comparison. --max-samples N runs a stratified subset into trust_<split>_smoke/
python scripts/eval_trust.py --run outputs/runs/<run-name> --split val
python scripts/compare_xai_paired.py --runs outputs/runs/ham10000_convnext_t outputs/runs/ham10000_hybrid --split val --map-a gradcam --maps-b gradcam_local gradcam_fused
```

- Models (`configs/model/`): ResNet-50, ConvNeXt-T and ViT-B/16 are used as timm classifiers. Swin-T and
  EfficientNetV2-S are a feature backbone plus a pooling head, and are also the single-branch ablations
  for the hybrid.
- Recipe (`configs/train/default.yaml`): AdamW (backbone 1e-4, head 1e-3), 3-epoch warmup + cosine, 30 epochs,
  AMP, gradient clipping 1.0, EMA 0.999, early stopping (patience 7) on val macro-F1 (HAM10000) or
  val AUC (ISIC 2020). Hardware profiles in `configs/train/` set batch size, accumulation and workers.
- `--hair-removed` trains on the DullRazor cache (with/without ablation, Milestone 3).
- Each run writes `outputs/runs/<name>/` (config.json, train.log, history.csv, best.pt, last.pt).
  `evaluate.py` adds `eval/` (metrics.json with bootstrap 95% CIs, predictions.csv, ROC/PR/confusion plots).
  `--val-only` writes `eval_val/` instead (metrics.json, predictions_val.csv, val confusion matrix).
  For binary tasks the test evaluation also reports the metrics at the thresholds in `eval_val/threshold.json`.
- `explain.py` writes `xai_<split>/` (maps.npz with raw maps per image, explain.json, figure strips);
  `eval_xai.py` adds per_image.csv and summary.json (IoU, Dice, box IoU, pointing game, energy in mask and on the
  lesion border, each also for a centred-Gaussian and a uniform reference map). Settings: `configs/xai/default.yaml`.
- `eval_trust.py` writes `trust_<split>/` (per_image.csv, summary.json with means, mean deletion / insertion curves
  and seconds per phase). It scores the Grad-CAM maps listed in `configs/xai/trust.yaml` plus a random and a
  centre reference map: deletion / insertion AUC, stability under flip / noise / brightness, and cascading
  parameter randomisation (the model is randomised in place last, so run it on a fresh process only).
  `compare_xai_paired.py` joins it with `xai_<split>/per_image.csv` and writes a paired bootstrap of each map of
  run B minus the map of run A, Holm-corrected over the `primary` endpoints, to `outputs/comparisons/`.
  The settings and endpoints are frozen (`docs/report_notes.md`, "M4 explanation trust").

## Project structure

```
configs/data/        dataset configs (paths, classes, split, DullRazor params)
configs/model/       one file per model
configs/train/       training recipe + hardware profiles
scripts/             entry points (PyCharm run configurations point here)
src/skin_lesion_xai/
  config.py          YAML -> DataConfig, ModelConfig, TrainConfig, XaiConfig, TrustConfig
  data/              dullrazor, splits, transforms, datasets, samplers, io
  models/            backbones, baselines, factory
  train/             losses, optimizer + schedule, trainer
  eval/              metrics (incl. bootstrap CIs), plots
  utils/             seeding, logging, checkpoints, device
docs/report_notes.md decisions, deviations and known limitations for the report
tests/               pytest: splits, DullRazor, image/mask alignment, models, metrics, trainer
data/, outputs/      generated (git-ignored)
```
