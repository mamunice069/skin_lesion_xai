"""Paired bootstrap of explanation-trust metrics: maps of run B minus a map of run A on the same images.

Usage: python scripts/compare_xai_paired.py --runs outputs/runs/<A> outputs/runs/<B> --split test \
           --map-a gradcam --maps-b gradcam_local gradcam_fused [--smoke]

Reads <run>/trust_<split>[_smoke]/per_image.csv (scripts/eval_trust.py) and <run>/xai_<split>[_smoke]/per_image.csv
(scripts/eval_xai.py, predicted-class maps; skipped with a log line if missing). Both runs must list the same
images in the same order. For every metric: values of A and B, B - A, percentile 95% CIs from the same
resampled image sets (configs/xai/trust.yaml n_boot, seed), and a two-sided bootstrap p-value. The endpoints in
`primary` (for every map of B) are Holm-corrected together; everything else is exploratory.
  *_vs_random   the map's deletion / insertion AUC minus that of the run's own random reference map
  iou_gap       mean IoU on correctly predicted images minus on wrong ones (each model its own correctness)
  rand_full_abs_{spearman,hog}  |rank correlation| of the trained and fully randomised maps: 0 = nothing of the
                trained map is left; the signed value would reward anti-correlation (changed after the val run)
Writes outputs/comparisons/<dataset>_xai_<split>_<B>_vs_<A>.json (+ .log).
"""
import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd

from skin_lesion_xai.config import PROJECT_DIR, TrustConfig
from skin_lesion_xai.eval.metrics import holm, paired_bootstrap_per_image
from skin_lesion_xai.utils.logging import get_logger
from skin_lesion_xai.xai import trust_dir, xai_dir

# metric -> which direction means a more trustworthy map
DIRECTION = {
    "deletion_auc": "lower", "insertion_auc": "higher", "deletion_vs_random": "lower", "insertion_vs_random": "higher",
    "rand_full_abs_spearman": "lower", "rand_full_ssim": "lower", "rand_full_abs_hog": "lower",
    "stab_spearman_mean": "higher", "stab_ssim_mean": "higher",
    "iou": "higher", "energy_in_mask": "higher", "pointing": "higher", "iou_gap": "higher",
}
LOCALISATION = ("iou", "energy_in_mask", "pointing")


def load(run_dir: Path, split: str, smoke: bool) -> tuple[pd.DataFrame, pd.DataFrame | None, Path]:
    trust = pd.read_csv(trust_dir(run_dir, split, smoke) / "per_image.csv")
    xai_path = xai_dir(run_dir, split, smoke=smoke) / "per_image.csv"
    if not xai_path.exists():
        return trust, None, xai_path
    xai = pd.read_csv(xai_path)
    return trust, xai[xai["target"] == "pred"], xai_path


def table(trust: pd.DataFrame, xai: pd.DataFrame | None, map_name: str) -> pd.DataFrame:
    """One row per image for one map: trust metrics, *_vs_random, localisation."""
    t = trust[trust["map"] == map_name].reset_index(drop=True)
    if t.empty:
        raise SystemExit(f"no rows for map {map_name}")
    ref = trust[trust["map"] == "ref_random"].set_index("image_id").loc[t["image_id"]].reset_index()
    for mode in ("deletion", "insertion"):
        t[f"{mode}_vs_random"] = t[f"{mode}_auc"].to_numpy() - ref[f"{mode}_auc"].to_numpy()
    for k in ("spearman", "hog"):
        if f"rand_full_{k}" in t.columns:
            t[f"rand_full_abs_{k}"] = t[f"rand_full_{k}"].abs()
    if xai is not None:
        x = xai[xai["method"] == map_name].set_index("image_id")
        if set(x.index) != set(t["image_id"]):
            raise SystemExit(f"localisation rows of {map_name} cover other images than the trust rows")
        for col in LOCALISATION:
            t[col] = x.loc[t["image_id"], col].to_numpy()
    return t


def main() -> None:
    p = argparse.ArgumentParser()
    p.add_argument("--runs", nargs=2, required=True, metavar=("A", "B"))
    p.add_argument("--split", default="test", choices=["val", "test"])
    p.add_argument("--map-a", default="gradcam")
    p.add_argument("--maps-b", nargs="+", default=["gradcam_local", "gradcam_fused"])
    p.add_argument("--trust-config", default="configs/xai/trust.yaml")
    p.add_argument("--smoke", action="store_true", help="compare the eval_trust.py --max-samples outputs")
    args = p.parse_args()

    tcfg = TrustConfig.from_yaml(args.trust_config)
    dirs = [Path(r) if Path(r).is_absolute() else PROJECT_DIR / r for r in args.runs]
    stem = f"{dirs[0].name.split('_')[0]}_xai_{args.split}{'_smoke' if args.smoke else ''}_{dirs[1].name}_vs_{dirs[0].name}"
    out_dir = PROJECT_DIR / "outputs" / "comparisons"
    (trust_a, xai_a, path_a), (trust_b, xai_b, path_b) = (load(d, args.split, args.smoke) for d in dirs)
    if (xai_a is None) != (xai_b is None):
        raise SystemExit(f"localisation scores exist for only one run ({path_a}, {path_b})")
    a = table(trust_a, xai_a, args.map_a)
    tables_b = {m: table(trust_b, xai_b, m) for m in args.maps_b}
    for b in tables_b.values():  # checked before anything is written
        if not (a["image_id"].equals(b["image_id"]) and a["label"].equals(b["label"])):
            raise SystemExit("the two runs do not list the same images and labels in the same order")
    log = get_logger("compare_xai_paired", out_dir / f"{stem}.log")
    if xai_a is None:
        log.info("%s not found: localisation metrics skipped", path_a)
    metrics = [m for m in DIRECTION if m in a.columns or m == "iou_gap" and "iou" in a.columns]

    results, primary_p = {}, {}
    for map_b, b in tables_b.items():
        results[map_b] = {}
        for metric in metrics:
            if metric == "iou_gap":
                r = paired_bootstrap_per_image(a["iou"], b["iou"], tcfg.n_boot, seed=tcfg.seed,
                                               correct_a=a["correct"], correct_b=b["correct"])
            else:
                r = paired_bootstrap_per_image(a[metric], b[metric], tcfg.n_boot, seed=tcfg.seed)
            r["better"] = DIRECTION[metric]
            results[map_b][metric] = r
            if metric in tcfg.primary:
                primary_p[f"{map_b}:{metric}"] = r["p_two_sided"]
    missing = [m for m in tcfg.primary if m not in metrics]
    for key, adj in holm(primary_p).items():
        map_b, metric = key.split(":")
        results[map_b][metric]["p_holm"] = adj

    out = {"a": f"{dirs[0].name}:{args.map_a}", "b": [f"{dirs[1].name}:{m}" for m in args.maps_b],
           "split": args.split, "smoke": args.smoke, "n": int(len(a)), "n_boot": tcfg.n_boot, "seed": tcfg.seed,
           "primary": tcfg.primary, "primary_missing": missing, "results": results}
    (out_dir / f"{stem}.json").write_text(json.dumps(out, indent=2))

    log.info("%s, n=%d, %d paired resamples; B - A, better = direction of a more trustworthy map", args.split,
             len(a), tcfg.n_boot)
    for map_b, res in results.items():
        log.info("B = %s:%s  vs  A = %s:%s", dirs[1].name, map_b, dirs[0].name, args.map_a)
        for metric, r in res.items():
            holm_txt = f"  Holm {r['p_holm']:.3f}" if "p_holm" in r else ""
            log.info("  %-20s (%-6s) A %.4f  B %.4f  B-A %+.4f [%+.4f, %+.4f]  p %.3f%s", metric, r["better"],
                     r["a"], r["b"], r["diff"], r["diff_ci"]["low"], r["diff_ci"]["high"], r["p_two_sided"], holm_txt)
    if missing:
        log.info("primary endpoints not available here: %s", missing)
    log.info("-> %s", out_dir / f"{stem}.json")


if __name__ == "__main__":
    main()
